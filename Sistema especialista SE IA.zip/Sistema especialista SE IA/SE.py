#essse sistma especialista traz umas carateristicas para dizer se um imovel é bom  de morar baseando nas normas da contrução civil.


from random import *
class Pergunta:
	def __init__(self):
		self.level = [
		['como está a base estrutural do imovel'],
		['como está a parte da das dosagens usadas nas estruras verticais e horizontais'];
		['por que usou essas dosgens mensionadas acima?'],
		['qual é a carga provisoria do imovel?'],
		['qual é a carga permanete ou contante do imovel?'],
		['como estão a situaçõa da oriêntação de bussol especialmente o ponto este das areas de descanço(os quartos)?'],
		['disponibiliza-se uma sala de estudo dentro do imovel,caso sim fica-se em qual area?'],
		['esse imovel se classifica-se em qual categoria? Big house ou casa grande de estandar ou normas internacionais?'],
		['esse imovl é acessivel a qualquer pessoa, pois para pensar construção temos que pensar da sociabilidade escialmente as 			pessoas com deficiência física'],
		['pensando nos quartos, os de criançã respeitam as nomas internacionais?'],
		['como está o sistema electrica e hydraulica dese imovel?'],
		['a região onde fica esse imovel nao tem uma boa estrutura de segurança publica ?'],
		['os critérios de privacidade desse imovel é padrão? A familia vai está vivendo com todas as libedades socias, economicas, 			culturais entre outras?'],
		['o plano de estudo do solo foi feito?'],
		['Havia uma pessoa que conheceu muito bem ou viveu durante muitos anos nessa região da contrução do imovel? o que foi falado 			dessa região nas tres ultimas décadas'],
		['como está o estado do imovel'],
		['como está a altura do imovel? é altura estandar?'],
		['como está o plano de da distribuiçaõ das?' tudo padronizado' se houve uma emergência a policia pode realizar algo?'],
		['como está a região do imovel pensando em investimento?'],
		
]
	def texto(self):
		string = self.level[0]
		del self.level[0]
		return string
		
		
		
		#essse sistma especialista traz umas carateristicas para dizer se um imovel é bom  de morar baseando nas normas da contrução civil.
		
