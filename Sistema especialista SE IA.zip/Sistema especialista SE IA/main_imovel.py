#essse sistma especialista traz umas carateristicas para dizer se um imovel é bom  de morar baseando nas normas da contrução civil.

from classDiagnostico import *
from classPerguntas import *

se = Diagnostico()
pergunta = Pergunta()


@@ -11,4 +11,4 @@
	print('probabilidade é %d' %(se.probabilidade()))
	print(se.resultado)
	if se.probabilidade() == 100:
		print('O seu imovel é bom para morar: ',se.resultado[0])	 
		
